import React, { useState } from 'react';
import api from '../api/api';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.post('/auth/login', { email: form.email, password: form.password });
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.user));
      navigate('/tasks');
    } catch (err) {
      let msg = 'Login failed';
      if (err.response) {
        msg = err.response.data?.msg || `Error: ${err.response.status} ${err.response.statusText}`;
      } else if (err.request) {
        msg = 'No response from server. Is backend running?';
      } else {
        msg = err.message;
      }
      setError(msg);
    }
  };

  return (
    <div className="card">
      <h2>Login</h2>
      <form onSubmit={submit}>
        <div className="form-row">
          <input className="input" name="email" placeholder="Email" value={form.email} onChange={onChange} />
        </div>
        <div className="form-row">
          <input type="password" className="input" name="password" placeholder="Password" value={form.password} onChange={onChange} />
        </div>
        <div style={{ marginTop: 8 }}>
          <button className="btn btn-primary" type="submit">Login</button>
        </div>
        {error && <p className="small" style={{ color: 'red' }}>{error}</p>}
      </form>
    </div>
  );
}
