import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div style={{ background: '#111827', color: 'white', padding: 12 }}>
      <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link to="/" style={{ color: 'white', textDecoration: 'none', fontWeight: 700 }}>Task Manager</Link>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {!token ? (
            <>
              <Link to="/login" style={{ color: 'white', textDecoration: 'none' }}>Login</Link>
              <Link to="/register" style={{ color: 'white', textDecoration: 'none' }}>Register</Link>
            </>
          ) : (
            <button className="btn" onClick={logout} style={{ background: '#ef4444', color: 'white', borderRadius: 6 }}>Logout</button>
          )}
        </div>
      </div>
    </div>
  );
}
