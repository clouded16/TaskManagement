import React, { useState } from 'react';
import api from '../api/api';

export default function TaskForm({ onAdd }) {
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', dueDate: '' });
  const [error, setError] = useState('');

  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.title.trim()) return setError('Title required');
    try {
      const res = await api.post('/tasks', form);
      onAdd(res.data);
      setForm({ title: '', description: '', priority: 'medium', dueDate: '' });
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to create task');
    }
  };

  return (
    <form onSubmit={submit}>
      <div className="form-row">
        <input name="title" className="input" placeholder="Task title" value={form.title} onChange={onChange} />
        <select name="priority" value={form.priority} onChange={onChange} style={{ padding: 8, borderRadius: 6 }}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </div>
      <div className="form-row">
        <input name="dueDate" className="input" type="date" value={form.dueDate} onChange={onChange} />
      </div>
      <div className="form-row">
        <input name="description" className="input" placeholder="Description" value={form.description} onChange={onChange} />
      </div>
      <div style={{ marginTop: 8 }}>
        <button className="btn btn-primary" type="submit">Add Task</button>
      </div>
      {error && <p className="small" style={{ color: 'red' }}>{error}</p>}
    </form>
  );
}
