import React, { useEffect, useState } from 'react';
import TaskForm from './TaskForm';
import TaskList from './TaskList';
import api from '../api/api';

export default function TasksPage() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setLoading(true);
      const res = await api.get('/tasks');
      setTasks(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const addTask = (task) => setTasks(prev => [task, ...prev]);
  const updateTask = (updated) => setTasks(prev => prev.map(t => (t._id === updated._id ? updated : t)));
  const removeTask = (id) => setTasks(prev => prev.filter(t => t._id !== id));

  return (
    <div>
      <div className="header">
        <h1>My Tasks</h1>
      </div>
      <div className="card">
        <TaskForm onAdd={addTask} />
      </div>

      <div style={{ marginTop: 12 }}>
        {loading ? <div className="card small">Loading tasks...</div> :
          <TaskList tasks={tasks} onUpdate={updateTask} onDelete={removeTask} />}
      </div>
    </div>
  );
}
