import React, { useState } from 'react';
import api from '../api/api';

export default function TaskItem({ task, onUpdate, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    title: task.title,
    description: task.description || '',
    priority: task.priority || 'medium',
    dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '',
    completed: !!task.completed
  });
  const [loading, setLoading] = useState(false);

  const toggleComplete = async () => {
    setLoading(true);
    try {
      const res = await api.put(`/tasks/${task._id}`, { ...form, completed: !form.completed });
      setForm(f => ({ ...f, completed: res.data.completed }));
      onUpdate(res.data);
    } catch (err) {
      console.error(err);
    } finally { setLoading(false); }
  };

  const save = async () => {
    setLoading(true);
    try {
      const res = await api.put(`/tasks/${task._id}`, { ...form });
      onUpdate(res.data);
      setEditing(false);
    } catch (err) {
      console.error(err);
    } finally { setLoading(false); }
  };

  const remove = async () => {
    if (!confirm('Delete this task?')) return;
    try {
      await api.delete(`/tasks/${task._id}`);
      onDelete(task._id);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div style={{ flex: 1 }}>
        {!editing ? (
          <div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input type="checkbox" checked={form.completed} onChange={toggleComplete} disabled={loading} />
              <div style={{ flex: 1 }}>
                <div className={form.completed ? 'task-completed' : ''}>
                  <strong>{form.title}</strong>
                  <span style={{ marginLeft: 8 }} className={`small priority-${form.priority}`}>{form.priority}</span>
                </div>
                <div className="small">{form.description}</div>
                <div className="small">Due: {form.dueDate || '—'}</div>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <input className="input" name="title" value={form.title} onChange={e => setForm({ ...form, [e.target.name]: e.target.value })} />
            <div className="form-row" style={{ marginTop: 8 }}>
              <input type="date" name="dueDate" className="input" value={form.dueDate} onChange={e => setForm({ ...form, dueDate: e.target.value })} />
              <select name="priority" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} style={{ padding: 8, borderRadius: 6 }}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
            <div className="form-row" style={{ marginTop: 8 }}>
              <input className="input" name="description" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
            </div>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 8, marginLeft: 12 }}>
        {editing ? (
          <>
            <button className="btn" onClick={save}>Save</button>
            <button className="btn" onClick={() => { setEditing(false); setForm({ ...form, title: task.title, description: task.description || '', priority: task.priority, dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '' }); }}>Cancel</button>
          </>
        ) : (
          <>
            <button className="btn" onClick={() => setEditing(true)}>Edit</button>
            <button className="btn btn-danger" onClick={remove}>Delete</button>
          </>
        )}
      </div>
    </div>
  );
}
