// server.js
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();
const connectDB = require('./config/db');

const app = express();
app.use(express.json());

// CORS: allow client (vite) origin or configure via CLIENT_URL in .env
const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:5174';
app.use(cors({ origin: CLIENT_URL, credentials: true }));

connectDB();

app.get('/', (req, res) => res.send('Task Manager API'));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/tasks', require('./routes/tasks'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
